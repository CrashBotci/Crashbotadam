from telegram.ext import Updater, CommandHandler, CallbackContext
from telegram import Update
import random

TOKEN = "7639420222:AAH71iqSjpZZw3bMp6Nu6UWDvJod6GoP9AI"

current_multiplier = 1.0
game_running = False

def start(update: Update, context: CallbackContext):
    update.message.reply_text(
        "🎉 Bienvenue sur CrashBot Jeunesse !\n"
        "Tape /play pour démarrer une partie."
    )

def play(update: Update, context: CallbackContext):
    global current_multiplier, game_running
    if game_running:
        update.message.reply_text("Une partie est déjà en cours, attends la fin !")
        return

    game_running = True
    current_multiplier = 1.0
    update.message.reply_text("🚀 Partie Crash démarrée ! Le multiplicateur va augmenter...")

    while current_multiplier < 5.0:
        current_multiplier += random.uniform(0.1, 0.5)
        update.message.reply_text(f"Multiplicateur actuel : x{current_multiplier:.2f}")

    update.message.reply_text(f"💥 Crash ! Multiplicateur final : x{current_multiplier:.2f}")
    game_running = False

def main():
    updater = Updater(TOKEN, use_context=True)
    dp = updater.dispatcher

    dp.add_handler(CommandHandler("start", start))
    dp.add_handler(CommandHandler("play", play))

    updater.start_polling()
    print("🤖 CrashBot en ligne...")
    updater.idle()

if __name__ == "__main__":
    main()
